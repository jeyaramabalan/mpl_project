// mpl-project/mpl-backend/controllers/playerController.js
const pool = require('../config/db');
const { formatOversDisplay, calculateAvg, calculateSR, calculateEcon, ballsToOversDecimal } = require('../utils/statsCalculations');

/**
 * @desc    Register a new player
 * @route   POST /api/players
 * @access  Admin Protected (via route)
 */
exports.registerPlayer = async (req, res, next) => {
    const { name, base_price, role } = req.body; // Removed email, phone
    // --- Validation ---
    if (!name) { return res.status(400).json({ message: 'Player name is required.' }); }
    const validRoles = ['Batsman', 'Bowler', 'AllRounder', 'WicketKeeper', null];
    if (role && !validRoles.includes(role)) { return res.status(400).json({ message: `Invalid role. Must be one of: ${validRoles.slice(0,-1).join(', ')} or empty.` }); }
    // --- End Validation ---
    try {
        const [result] = await pool.query('INSERT INTO players (name, base_price, role, current_team_id) VALUES (?, ?, ?, NULL)', [ name, base_price === undefined || base_price === null ? 100.00 : base_price, role || null ]);
        const playerId = result.insertId;
        const [newPlayer] = await pool.query('SELECT player_id, name, base_price, role, current_team_id FROM players WHERE player_id = ?', [playerId]);
        if (newPlayer.length === 0) throw new Error('Failed to retrieve newly registered player.');
        res.status(201).json({ message: 'Player registered successfully', player: newPlayer[0] });
    } catch (error) { console.error("Player Registration Error:", error); next(error); }
};

/**
 * @desc    Get all players (basic list)
 * @route   GET /api/players
 * @access  Public
 */
exports.getAllPlayers = async (req, res, next) => {
    try {
        const [players] = await pool.query(
            `SELECT p.player_id, p.name, p.role, t.name as current_team_name,
             COALESCE((SELECT COUNT(DISTINCT match_id) FROM playermatchstats WHERE player_id = p.player_id), 0) as matches_played
             FROM players p
             LEFT JOIN teams t ON p.current_team_id = t.team_id
             ORDER BY p.name ASC`
        );
        res.json(players);
    } catch (error) { console.error("Get All Players Error:", error); next(error); }
};

/**
 * @desc    Get details of a single player by ID
 * @route   GET /api/players/:id
 * @access  Public
 */
exports.getPlayerById = async (req, res, next) => {
     const { id } = req.params; if (isNaN(parseInt(id))) { return res.status(400).json({ message: 'Invalid Player ID.' }); }
    try {
        const playerQuery = ` SELECT p.player_id, p.name, p.base_price, p.role, p.current_team_id, t.name as current_team_name FROM players p LEFT JOIN teams t ON p.current_team_id = t.team_id WHERE p.player_id = ? `;
        const [players] = await pool.query(playerQuery, [id]);
        if (players.length === 0) { return res.status(404).json({ message: 'Player not found.' }); }
        const playerData = players[0];
        const impactQuery = ` SELECT SUM(COALESCE(batting_impact_points, 0) + COALESCE(bowling_impact_points, 0) + COALESCE(fielding_impact_points, 0)) as total_impact, COUNT(DISTINCT match_id) as matches_played FROM playermatchstats WHERE player_id = ? GROUP BY player_id `;
        const [impactRes] = await pool.query(impactQuery, [id]); let averageImpact = 0; if (impactRes.length > 0 && impactRes[0].matches_played > 0) { averageImpact = impactRes[0].total_impact / impactRes[0].matches_played; }
        const responseData = { ...playerData, average_impact: parseFloat(averageImpact.toFixed(2)) };
        res.json(responseData);
    } catch (error) { console.error("Get Player By ID Error:", error); next(error); }
};

/**
 * @desc    Get aggregated player statistics (career or filtered by season)
 * @route   GET /api/players/:id/stats?season_id=X
 * @access  Public
 */
exports.getPlayerStats = async (req, res, next) => {
    const playerId = req.params.id;
    const { season_id } = req.query;
    // Use pool directly unless transaction is needed across queries
    // const connection = await pool.getConnection();

    if (isNaN(parseInt(playerId))) { return res.status(400).json({ message: 'Invalid Player ID.' }); }
    if (season_id && isNaN(parseInt(season_id))) { return res.status(400).json({ message: 'Invalid Season ID provided in query parameter.' }); }

    try {
        // --- Query 1: Fetch Main Aggregated Stats ---
        let query = `
            SELECT
                p.player_id, p.name, p.role,
                COUNT(DISTINCT pms.match_id) as matches_played,
                COALESCE(SUM(pms.runs_scored), 0) as total_runs,
                COALESCE(SUM(pms.balls_faced), 0) as total_balls_faced,
                MAX(COALESCE(pms.runs_scored, 0)) as highest_score,
                COALESCE(SUM(pms.fours), 0) as total_fours,
                COALESCE(SUM(pms.twos), 0) as total_twos,
                COALESCE(SUM(CASE WHEN pms.is_out = TRUE THEN 1 ELSE 0 END), 0) as times_out,
                COALESCE(SUM(pms.wickets_taken), 0) as total_wickets,
                COALESCE(SUM(pms.runs_conceded), 0) as total_runs_conceded,
                COALESCE(SUM(FLOOR(pms.overs_bowled) * 6 + LEAST(5, ROUND((pms.overs_bowled - FLOOR(pms.overs_bowled)) * 10))), 0) as total_balls_bowled,
                COALESCE(SUM(pms.maidens), 0) as total_maidens,
                COALESCE(SUM(pms.wides), 0) as total_wides,
                COALESCE(SUM(pms.no_balls), 0) as total_no_balls,
                COALESCE(SUM(pms.catches), 0) as total_catches,
                COALESCE(SUM(pms.stumps), 0) as total_stumps,
                COALESCE(SUM(pms.run_outs), 0) as total_run_outs,
                COALESCE(SUM(pms.batting_impact_points), 0) as total_batting_impact,
                COALESCE(SUM(pms.bowling_impact_points), 0) as total_bowling_impact,
                COALESCE(SUM(pms.fielding_impact_points), 0) as total_fielding_impact
            FROM players p
            LEFT JOIN playermatchstats pms ON p.player_id = pms.player_id
        `;
        const params = [];
        let joinClause = '';
        let whereClause = ' WHERE p.player_id = ?'; params.push(playerId);

        if (season_id) {
            joinClause = ' LEFT JOIN matches m ON pms.match_id = m.match_id';
            whereClause += ' AND m.season_id = ?'; params.push(season_id);
        }
        query += joinClause + whereClause + ' GROUP BY p.player_id, p.name, p.role';

        const [statsArr] = await pool.query(query, params); // Use pool

        // --- Handle No Stats Found ---
        if (statsArr.length === 0) {
             const [playerCheck] = await pool.query('SELECT player_id, name, role FROM players WHERE player_id = ?', [playerId]);
             if (playerCheck.length === 0) { return res.status(404).json({ message: 'Player not found.' }); }
             else {
                const emptyBucket = { overs_count: 0, overs_display: '0.0', maidens: 0, wickets: 0, runs: 0, economy: null };
                return res.json({ ...playerCheck[0], matches_played: 0, total_runs: 0, total_balls_faced: 0, highest_score: 0, total_fours: 0, total_twos: 0, times_out: 0, total_wickets: 0, total_runs_conceded: 0, total_overs_bowled: 0.0, total_maidens: 0, total_wides: 0, total_no_balls: 0, total_catches: 0, total_stumps: 0, total_run_outs: 0, total_batting_impact: 0, total_bowling_impact: 0, total_fielding_impact: 0, average_impact: 0, super_overs_bowled: 0, bowling_breakdown: { normal: { ...emptyBucket }, super: { ...emptyBucket }, total: { ...emptyBucket } }, batting_average: null, batting_strike_rate: null, bowling_average: null, bowling_economy_rate: null, bowling_strike_rate: null });
            }
        }

        let stats = statsArr[0];
        // Convert summed balls to cricket overs (fixes invalid e.g. 99.8 from decimal sum)
        const totalBallsBowled = stats.total_balls_bowled ?? 0;
        stats.total_overs_bowled = parseFloat(ballsToOversDecimal(totalBallsBowled).toFixed(1));
        delete stats.total_balls_bowled;

        // --- Query 2: Calculate Super Overs Bowled --- // ADDED THIS QUERY
        let superOverQuery = `
            SELECT COUNT(DISTINCT b.match_id) as super_overs_bowled
            FROM ballbyball b
            JOIN matches m ON b.match_id = m.match_id
            WHERE b.bowler_player_id = ?
              AND b.over_number = m.super_over_number
        `;
        const superOverParams = [playerId];
        if (season_id) {
            superOverQuery += ' AND m.season_id = ?';
            superOverParams.push(season_id);
        }
        const [superOverRes] = await pool.query(superOverQuery, superOverParams);
        stats.super_overs_bowled = superOverRes[0]?.super_overs_bowled || 0; // Add to stats object
        // --- End Super Over Query ---

        // --- Query 3: Bowling breakdown (Normal Overs / Super Overs / Total) from ballbyball ---
        let breakdownParams = [playerId];
        let breakdownFilter = 'WHERE b.bowler_player_id = ?';
        if (season_id) {
            breakdownFilter += ' AND m.season_id = ?';
            breakdownParams.push(season_id);
        }
        const breakdownQuery = `
            SELECT
                (b.over_number = m.super_over_number) AS is_super,
                SUM(CASE WHEN b.is_extra = 0 THEN 1 ELSE 0 END) AS legal_balls,
                SUM(
                    (CASE WHEN b.is_bye = 0 THEN (CASE WHEN b.is_extra = 0 THEN b.runs_scored WHEN b.extra_type = 'NoBall' THEN b.runs_scored ELSE 0 END) ELSE 0 END)
                    + (CASE WHEN b.is_extra = 1 THEN COALESCE(b.extra_runs, 0) ELSE 0 END)
                ) AS runs_conceded,
                SUM(CASE WHEN b.is_wicket = 1 AND (b.wicket_type IS NULL OR b.wicket_type != 'Run Out') THEN 1 ELSE 0 END) AS wickets
            FROM ballbyball b
            JOIN matches m ON b.match_id = m.match_id
            ${breakdownFilter}
            GROUP BY is_super
        `;
        const [breakdownRows] = await pool.query(breakdownQuery, breakdownParams);
        const maidenQuery = `
            SELECT (m.super_over_number = o.over_number) AS is_super, COUNT(*) AS maidens
            FROM (
                SELECT b.match_id, b.inning_number, b.over_number, b.bowler_player_id,
                    SUM(CASE WHEN b.is_extra = 0 THEN 1 ELSE 0 END) AS legal_balls,
                    SUM(
                        (CASE WHEN b.is_bye = 0 THEN (CASE WHEN b.is_extra = 0 THEN b.runs_scored WHEN b.extra_type = 'NoBall' THEN b.runs_scored ELSE 0 END) ELSE 0 END)
                        + (CASE WHEN b.is_extra = 1 THEN COALESCE(b.extra_runs, 0) ELSE 0 END)
                    ) AS runs
                FROM ballbyball b
                WHERE b.bowler_player_id = ?
                GROUP BY b.match_id, b.inning_number, b.over_number, b.bowler_player_id
            ) o
            JOIN matches m ON o.match_id = m.match_id
            WHERE o.legal_balls = 6 AND o.runs = 0
            ${season_id ? 'AND m.season_id = ?' : ''}
            GROUP BY is_super
        `;
        const maidenParams = [playerId];
        if (season_id) maidenParams.push(season_id);
        const [maidenRows] = await pool.query(maidenQuery, maidenParams);
        // Build bowling_breakdown: normal, super, total
        const bySuper = { 0: { legal_balls: 0, runs_conceded: 0, wickets: 0, maidens: 0 }, 1: { legal_balls: 0, runs_conceded: 0, wickets: 0, maidens: 0 } };
        breakdownRows.forEach((r) => {
            const key = r.is_super ? 1 : 0;
            bySuper[key].legal_balls = Number(r.legal_balls ?? 0);
            bySuper[key].runs_conceded = Number(r.runs_conceded ?? 0);
            bySuper[key].wickets = Number(r.wickets ?? 0);
        });
        maidenRows.forEach((r) => {
            const key = r.is_super ? 1 : 0;
            bySuper[key].maidens = Number(r.maidens ?? 0);
        });
        const normal = bySuper[0];
        const superBucket = bySuper[1];
        const totalBalls = normal.legal_balls + superBucket.legal_balls;
        const totalRuns = normal.runs_conceded + superBucket.runs_conceded;
        const totalWickets = normal.wickets + superBucket.wickets;
        const totalMaidens = normal.maidens + superBucket.maidens;
        const buildBucket = (legalBalls, runs, wickets, maidens) => {
            const oversDecimal = legalBalls > 0 ? ballsToOversDecimal(legalBalls) : 0;
            const economy = legalBalls > 0 ? parseFloat((runs / (legalBalls / 6)).toFixed(2)) : null;
            return {
                overs_count: parseFloat(oversDecimal.toFixed(1)),
                overs_display: formatOversDisplay(oversDecimal),
                maidens: maidens,
                wickets: wickets,
                runs: runs,
                economy: economy,
            };
        };
        stats.bowling_breakdown = {
            normal: buildBucket(normal.legal_balls, normal.runs_conceded, normal.wickets, normal.maidens),
            super: buildBucket(superBucket.legal_balls, superBucket.runs_conceded, superBucket.wickets, superBucket.maidens),
            total: buildBucket(totalBalls, totalRuns, totalWickets, totalMaidens),
        };
        // --- End Bowling Breakdown ---

        // --- Calculate Derived Statistics ---
        stats.batting_average = calculateAvg(stats.total_runs, stats.times_out);
        stats.batting_strike_rate = calculateSR(stats.total_runs, stats.total_balls_faced);
        stats.bowling_economy_rate = calculateEcon(stats.total_runs_conceded, stats.total_overs_bowled);
        const totalImpact = (stats.total_batting_impact || 0) + (stats.total_bowling_impact || 0) + (stats.total_fielding_impact || 0);
        stats.average_impact = stats.matches_played > 0 ? totalImpact / stats.matches_played : 0;

        // --- Formatting ---
        if (stats.batting_average === Infinity) { stats.batting_average_display = "Not Out"; stats.batting_average = null; }
        else { stats.batting_average_display = stats.batting_average !== null ? stats.batting_average.toFixed(2) : '-'; }
        stats.batting_strike_rate = stats.batting_strike_rate !== null ? parseFloat(stats.batting_strike_rate.toFixed(2)) : null;
        stats.bowling_economy_rate = stats.bowling_economy_rate !== null ? parseFloat(stats.bowling_economy_rate.toFixed(2)) : null;
        stats.average_impact = parseFloat(stats.average_impact.toFixed(2));

        res.json(stats);
    } catch (error) { console.error("Get Player Stats Error:", error); next(error); }
    // finally { if (connection) connection.release(); } // Remove if not using connection
};

/**
 * @desc    Get player stats for last N matches (per-match breakdown)
 * @route   GET /api/players/:id/stats/by-match?limit=5
 * @access  Public
 */
exports.getPlayerStatsByMatch = async (req, res, next) => {
    const playerId = req.params.id;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 5, 1), 50);

    if (isNaN(parseInt(playerId))) {
        return res.status(400).json({ message: 'Invalid Player ID.' });
    }

    try {
        const [rows] = await pool.query(
            `SELECT
                pms.match_id,
                m.match_datetime,
                pms.runs_scored,
                pms.balls_faced,
                COALESCE(pms.fours, 0) as fours,
                COALESCE(pms.wickets_taken, 0) as wickets_taken,
                COALESCE(pms.runs_conceded, 0) as runs_conceded,
                COALESCE(pms.overs_bowled, 0) as overs_bowled,
                COALESCE(pms.batting_impact_points, 0) as batting_impact_points,
                COALESCE(pms.bowling_impact_points, 0) as bowling_impact_points,
                COALESCE(pms.fielding_impact_points, 0) as fielding_impact_points,
                CASE WHEN pms.team_id = m.team1_id THEN t2.name ELSE t1.name END AS opponent_team_name
            FROM playermatchstats pms
            INNER JOIN matches m ON pms.match_id = m.match_id
            LEFT JOIN teams t1 ON m.team1_id = t1.team_id
            LEFT JOIN teams t2 ON m.team2_id = t2.team_id
            WHERE pms.player_id = ?
            ORDER BY m.match_datetime DESC
            LIMIT ?`,
            [playerId, limit]
        );

        const matches = rows.map((r) => ({
            match_id: r.match_id,
            match_datetime: r.match_datetime,
            opponent_team_name: r.opponent_team_name || null,
            runs_scored: r.runs_scored ?? 0,
            balls_faced: r.balls_faced ?? 0,
            fours: r.fours ?? 0,
            wickets_taken: r.wickets_taken ?? 0,
            runs_conceded: r.runs_conceded ?? 0,
            overs_bowled: parseFloat(r.overs_bowled ?? 0),
            batting_impact_points: parseFloat(r.batting_impact_points ?? 0),
            bowling_impact_points: parseFloat(r.bowling_impact_points ?? 0),
            fielding_impact_points: parseFloat(r.fielding_impact_points ?? 0),
            total_impact: parseFloat((r.batting_impact_points ?? 0) + (r.bowling_impact_points ?? 0) + (r.fielding_impact_points ?? 0)),
        }));

        res.json({ matches });
    } catch (error) {
        console.error('Get Player Stats By Match Error:', error);
        next(error);
    }
};

/**
 * @desc    Get player stats aggregated by last N seasons
 * @route   GET /api/players/:id/stats/by-season?limit=5
 * @access  Public
 */
exports.getPlayerStatsBySeason = async (req, res, next) => {
    const playerId = req.params.id;
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 5, 1), 20);

    if (isNaN(parseInt(playerId))) {
        return res.status(400).json({ message: 'Invalid Player ID.' });
    }

    try {
        const [rows] = await pool.query(
            `SELECT
                s.season_id,
                s.year,
                s.name as season_name,
                COUNT(DISTINCT pms.match_id) as matches_played,
                COALESCE(SUM(pms.runs_scored), 0) as total_runs,
                COALESCE(SUM(pms.balls_faced), 0) as total_balls_faced,
                COALESCE(SUM(pms.wickets_taken), 0) as total_wickets,
                COALESCE(SUM(pms.runs_conceded), 0) as total_runs_conceded,
                COALESCE(SUM(FLOOR(pms.overs_bowled) * 6 + LEAST(5, ROUND((pms.overs_bowled - FLOOR(pms.overs_bowled)) * 10))), 0) as total_balls_bowled,
                COALESCE(SUM(pms.batting_impact_points), 0) as batting_impact,
                COALESCE(SUM(pms.bowling_impact_points), 0) as bowling_impact,
                COALESCE(SUM(pms.fielding_impact_points), 0) as fielding_impact,
                COALESCE(SUM(pms.batting_impact_points), 0) + COALESCE(SUM(pms.bowling_impact_points), 0) + COALESCE(SUM(pms.fielding_impact_points), 0) as total_impact
            FROM playermatchstats pms
            INNER JOIN matches m ON pms.match_id = m.match_id
            INNER JOIN seasons s ON m.season_id = s.season_id
            WHERE pms.player_id = ?
            GROUP BY s.season_id, s.year, s.name
            ORDER BY s.year DESC, s.season_id DESC
            LIMIT ?`,
            [playerId, limit]
        );

        const seasons = rows.map((r) => {
            const totalBalls = r.total_balls_bowled ?? 0;
            const totalOversBowled = parseFloat(ballsToOversDecimal(totalBalls).toFixed(1));
            return {
                season_id: r.season_id,
                year: r.year,
                name: r.season_name,
                matches_played: r.matches_played,
                total_runs: r.total_runs,
                total_balls_faced: r.total_balls_faced ?? 0,
                total_wickets: r.total_wickets ?? 0,
                total_runs_conceded: r.total_runs_conceded ?? 0,
                total_overs_bowled: totalOversBowled,
                total_impact: parseFloat(r.total_impact ?? 0),
                batting_impact: parseFloat(r.batting_impact ?? 0),
                bowling_impact: parseFloat(r.bowling_impact ?? 0),
                fielding_impact: parseFloat(r.fielding_impact ?? 0),
            };
        });

        res.json({ seasons });
    } catch (error) {
        console.error('Get Player Stats By Season Error:', error);
        next(error);
    }
};

/**
 * @desc    Update player details
 * @route   PUT /api/players/:id
 * @access  Admin (Protected)
 */
exports.updatePlayer = async (req, res, next) => {
    const { id } = req.params;
    // MODIFIED: Removed email, phone
    const { name, base_price, role } = req.body;

    if (isNaN(parseInt(id))) {
        return res.status(400).json({ message: 'Invalid Player ID.' });
    }
    // Check if any valid update data is provided
    if (name === undefined && base_price === undefined && role === undefined) {
        return res.status(400).json({ message: 'No update data provided (name, base_price, role).' });
    }

    try {
        // Check if player exists
        const [existing] = await pool.query('SELECT player_id FROM players WHERE player_id = ?', [id]);
        if (existing.length === 0) {
            return res.status(404).json({ message: 'Player not found.' });
        }

        // Build fields to update dynamically
        const fieldsToUpdate = {};
        if (name !== undefined) fieldsToUpdate.name = name;
        if (base_price !== undefined) fieldsToUpdate.base_price = base_price;
        if (role !== undefined) fieldsToUpdate.role = role || null;

        // Perform update if there are fields to change
        if (Object.keys(fieldsToUpdate).length > 0) {
            const [result] = await pool.query('UPDATE players SET ? WHERE player_id = ?', [fieldsToUpdate, id]);
             if (result.affectedRows === 0) {
                console.warn(`Update Player ${id}: Affected rows was 0. Data might be unchanged.`);
             }
        } else {
             return res.status(304).json({ message: 'No changes detected.' });
        }

        // Fetch updated player details (excluding sensitive/derived fields)
        const [updatedPlayer] = await pool.query('SELECT player_id, name, base_price, role, current_team_id FROM players WHERE player_id = ?', [id]);
        res.json({ message: 'Player updated successfully', player: updatedPlayer[0] });

    } catch (error) {
        console.error("Update Player Error:", error);
        next(error);
    }
};

/**
 * @desc    Delete a player (Use with caution!)
 * @route   DELETE /api/players/:id
 * @access  Admin (Protected)
 */
exports.deletePlayer = async (req, res, next) => {
    const { id } = req.params;
    if (isNaN(parseInt(id))) {
        return res.status(400).json({ message: 'Invalid Player ID.' });
    }

    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();

        // Check if player exists
         const [existing] = await connection.query('SELECT player_id FROM players WHERE player_id = ?', [id]);
        if (existing.length === 0) {
            await connection.rollback(); return res.status(404).json({ message: 'Player not found.' });
        }

        // Block delete if player has played in at least one match (preserves scorecards and stats)
        const [played] = await connection.query('SELECT 1 FROM playermatchstats WHERE player_id = ? LIMIT 1', [id]);
        if (played.length > 0) {
            await connection.rollback();
            return res.status(403).json({ message: 'Cannot delete a player who has played in at least one match.' });
        }

        // --- Handle Foreign Key References ---
        await connection.query('UPDATE teams SET captain_player_id = NULL WHERE captain_player_id = ?', [id]);
        await connection.query('UPDATE matches SET man_of_the_match_player_id = NULL WHERE man_of_the_match_player_id = ?', [id]);
        // Assuming ratings should be kept but reference nulled (adjust if cascading delete is desired)
        // await connection.query('UPDATE PlayerRatings SET rater_player_id = NULL WHERE rater_player_id = ?', [id]);
        // await connection.query('UPDATE PlayerRatings SET rated_player_id = NULL WHERE rated_player_id = ?', [id]);

        // Explicitly delete from TeamPlayers junction table
        await connection.query('DELETE FROM teamplayers WHERE player_id = ?', [id]);
        console.log(`Deleted TeamPlayers entries for player ${id}`);

        // NOTE: Deletion will fail if player has stats in PlayerMatchStats and FK constraint is RESTRICT.
        // Handle this based on your desired behavior (e.g., delete stats too? Disallow player delete?).

        // Finally, attempt to delete the player
        const [result] = await connection.query('DELETE FROM players WHERE player_id = ?', [id]);

        if (result.affectedRows === 0) {
             await connection.rollback();
             return res.status(404).json({ message: 'Player not found or could not be deleted (possibly due to existing references like match stats).' });
        }

        await connection.commit();
        res.status(200).json({ message: 'Player deleted successfully.' });

    } catch (error) {
        await connection.rollback();
        console.error("Delete Player Error:", error);
        if (error.code === 'ER_ROW_IS_REFERENCED_2') {
            return res.status(400).json({ message: 'Cannot delete player. They are referenced in other records (e.g., match stats, payments) that prevent deletion. Check foreign key constraints or remove references first.' });
        }
        next(error);
    } finally {
        connection.release();
    }
};